MOON DESCENT v1.11 · CAMPAIGN & DAILY DESCENT

Extract the ZIP and open index.html in a modern browser. The game
runs entirely offline.

GUIDED LANDING
  Choose Watch demo from the flight plan. The lander shows how
  to steer, brake sideways and land on the flat top of the 7
  in the J7 rock formations. After
  touchdown, choose Try it yourself to fly the same approach.
  Training flights use Cadet settings and are unscored.

SCOREBOARD
  Look below the game for your current score, the relevant best
  score, and your latest landing or crash. On touchscreens, a
  compact score also appears beside the beacon button.

  In a campaign, the scoreboard shows sectors cleared, landing
  points and total crash deductions. In Daily Descent or sector
  practice, it shows the points needed to match an existing best.

SIX-SECTOR CAMPAIGN
  Ridge Crossing, South Pole Rescue, Crater Run, Far Side Traverse,
  Switchback and Rail Dock form a single scored run.

  Each safe landing adds its points to the total. Landing quality,
  fuel remaining and the pad multiplier all count. Each crash
  subtracts 500 points from the run. Retry restarts the current
  sector. The campaign best is recorded after you land in all six
  sectors. Campaign bests are separate for Cadet, Pilot and Ace.

  A run lasts for the current play session. Reloading the page or
  opening the flight plan again starts a fresh run. Choose a named
  sector in the flight plan to practise it and chase its own best.

DAILY DESCENT
  Choose Daily Descent in the flight plan. One new route is
  generated from the UTC date and works without an internet
  connection. Players on the same date and difficulty get the
  same route. Retry keeps the route until a new UTC day starts.
  A flight already under way keeps its original route and score date.

CONTROLS
  Rotate      Left/Right or A/D
  Thrust      Up, W or Space (hold)
  Pause       P or Escape
  Beacon      B (or tap Beacon)
  Flight plan R
  Continue    Enter on the result screen

The beacon cycles Alpha, Bravo, and Off. It pans toward the
selected pad and quickens as you close in. A steady tone and
READY label indicate safe approach conditions at that moment.

On touchscreens, you can hold steering and thrust together.
Release or slide off a button to stop that input. Best scores
are stored in the browser when local storage is available.
